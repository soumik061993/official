"""Importing psycopg2 module to connect to database"""
import psycopg2

# Query - "Top 3 popular articles of all time"
s1 = "select title,views from articles_view limit 3"

# Query - "Most popular article authors of all time"
s2 = "select * from articles_authors_view"

# Query - "Days in which more than 1% of requests lead to errors"
s3 = "select * from error_log_view where error_perc > 1"


def connectdb():


    """Returns the connection object"""
    return psycopg2.connect("dbname=news")
	
	
# function to set title to each query


def set_header(statement)

    
    """This function sets headers for each query"""
    if 'articles_view' in statement: 
        header = "\n1) The top 3 popular articles of all time are:\n"
    if 'articles_author_view' in statement:
        header = "\n2) Most popular authors of all time are:\n"
    if 'error_log_view' in statement:
        header = "\n3) Days with more than 1% of error requests:\n"
    return header


# function for fetching query data


def fetch_query(query):
    
	
	"""This function connects to database and extracts data based on query passed"""
        dbconn = connectdb()
        conobj = dbconn.cursor()
        conobj.execute(query)
        querydata = conobj.fetchall()
        dbconn.close()
        return querydata    	

# function to execute each query

		
def exec_query(header, result):


    """This function prints the data extracted"""
        if 'popular' in header:
            print(header)
            for res in result:
                print('\t' + str(res[0]) + ' - ' + str(res[1]) + ' views')
        else:
            print(header)
            for res in result:
                print('\t' + str(res[0]) + ' - ' + str(res[1]) + ' %')


				
def store_query():

    """This function stores each of query headers & records"""
	   h1 = set_header(s1)
	   h2 = set_header(s2)
	   h3 = set_header(s3)
	
       query_dict = {h1 : fetch_query(s1),h2 : fetch_query(s2),h3 : fetch_query(s3)}
	
	   exec_query(h1, query_dict[h1])
	   exec_query(h2, query_dict[h2])
	   exec_query(h3, query_dict[h3])
	     
if __name__ == '__main__':
    
	"""Execute the main function"""
	   store_query()
