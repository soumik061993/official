#Log-Analysis
Logs Analysis Project for completion of [Udacity's Front-End Web Developer Nanodegree]

###Project Descriptiontion
In this project, you'll work with data that could have come from a real-world web application, with fields representing information that a web server would record, such as HTTP status codes and URL paths. The web server and the reporting tool both connect to the same database, allowing information to flow from the web server into the report.

### PreRequisites:
  1 Python2
  2 Vagrant
  3 VirtualBox
  
###Launching the Virtual Machine:
  1. Launch the Vagrant VM inside Vagrant sub-directory in the downloaded fullstack-nanodegree-vm repository using command:
  
  $ vagrant up
	
  2. Log in using command:
  
  $ vagrant ssh
 
  
###Setting up the database:

  1. Load the data in local database using the command:
  
  psql -d news -f newsdata.sql
  
  2. Use `psql -d news` to connect to database.
  
  3. Create view articles_view using:
  
    create view articles_view as select title,author,count(*) as views from articles,log where 
    log.path like concat('%',articles.slug) group by articles.title,articles.author 
    order by views desc;
  
  4. Create view error_log_view using:
  
    create view error_log_view as select date(time),round(100.0*sum(case log.status when '200 OK' 
    then 0 else 1 end)/count(log.status),2) as error_perc from log group by date(time) 
    order by error_perc desc;

	
  5. Create articles_authors_view using:
		
	select authors.name,sum(article_view.views) as views from
	article_view,authors where authors.id = article_view.author
	group by authors.name order by views desc
	

  
#### Run the Queries
  1. From the vagrant directory inside the virtual machine,we will run logs.py using:

    $ python2 logs.py